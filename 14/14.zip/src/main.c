/***************************************************************
 * File: main.c
 * Description: Main entry point for the assembler program.
 ***************************************************************/

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "assembler.h"
#include "preprocessing.h"
#include "first_pass.h"
#include "second_pass.h"
#include "helper_functions.h"

/* Function prototypes */
char* create_filename(const char* base, const char* extension);
int process_file(const char* base_filename);

/* create_filename: Creates a new filename by appending an extension */
char* create_filename(const char* base, const char* extension)
{
    char* filename;
    size_t len;

    /* Calculate required length for the new filename */
    len = strlen(base) + (extension ? strlen(extension) : 0) + 1;
    
    /* Allocate memory for the new filename */
    filename = malloc(len);
    if (!filename) {
        perror("Memory allocation failed");
        exit(1);
    }
    
    /* Construct the new filename */
    strcpy(filename, base);
    if (extension) {
        strcat(filename, extension);
    }
    
    return filename;
}

int process_file(const char* base_filename)
{
    char* input_filename;
    char* am_filename;
    FILE* test_file;
    SymbolTable symbol_table;
    MemoryImage memory_image;
    int result = 0;

    /* Attempt to open the input file with .as extension */
    input_filename = create_filename(base_filename, ".as");
    test_file = fopen(input_filename, "r");
    if (!test_file) {
        /* If failed, try opening without extension */
        free(input_filename);
        input_filename = strdup(base_filename);
        test_file = fopen(input_filename, "r");
        if (!test_file) {
            printf("Error: Cannot open input file %s or %s.as\n", base_filename, base_filename);
            free(input_filename);
            return 1;
        }
    }
    fclose(test_file);

    /* Create filename for the preprocessed file */
    am_filename = create_filename(base_filename, ".am");

    printf("Processing file: %s\n", input_filename);

    reset_error_count();  /* Reset error count for this file */

    /* Preprocessing stage */
    printf("Starting preprocessing...\n");
    if (preprocess_file(input_filename) != 0) {
        printf("Error: Preprocessing failed for file %s\n", input_filename);
        free(input_filename);
        free(am_filename);
        return 1;
    }
    printf("Preprocessing completed.\n");

    /* First pass stage */
    printf("Starting first pass...\n");
    symbol_table = create_symbol_table();
    if (first_pass(am_filename, &symbol_table) != 0) {
        printf("Error: First pass failed for file %s\n", am_filename);
        result = 1;
    }

    if (result == 0) {
        printf("First pass completed successfully.\n");

        /* Second pass stage */
        printf("Starting second pass...\n");
        init_memory_image(&memory_image);
        if (second_pass(am_filename, &symbol_table, &memory_image) != 0) {
            printf("Error: Second pass failed for file %s\n", am_filename);
            result = 1;
        }

        if (result == 0) {
            printf("Second pass completed successfully.\n");

            /* Generate output files */
            printf("Generating output files...\n");
            write_output_files(base_filename, &memory_image, &symbol_table);
            printf("Output files generated.\n");
        }

        free_memory_image(&memory_image);
    }

    free_symbol_table(&symbol_table);

    /* Check for errors and report */
    if (result != 0) {
        printf("Errors were found during processing. No output files generated for %s.\n", base_filename);
        /* Remove the .am file if it exists */
        remove(am_filename);
    }

    printf("Processing completed for file: %s\n\n", base_filename);

    /* Clean up */
    free(input_filename);
    free(am_filename);

    return result;
}

/* main: Entry point of the assembler program */
int main(int argc, char *argv[])
{
    int i;
    int total_files = 0;
    int files_with_errors = 0;
    int result;

    /* Check for correct usage */
    if (argc < 2) {
        printf("Usage: %s <filename1> [filename2 ...]\n", argv[0]);
        return 1;
    }

    /* Process each input file */
    for (i = 1; i < argc; i++) {
        printf("Processing file %d of %d: %s\n", i, argc - 1, argv[i]);
        result = process_file(argv[i]);
        total_files++;
        if (result != 0) {
            files_with_errors++;
        }
        printf("\n");
    }

    /* Print summary */
    printf("Assembly process completed.\n");
    printf("Total files processed: %d\n", total_files);
    printf("Files assembled successfully: %d\n", total_files - files_with_errors);
    printf("Files with errors: %d\n", files_with_errors);

    return files_with_errors > 0 ? 1 : 0;
}